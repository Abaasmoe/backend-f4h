package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AmSkF4HUserLgRApplication {

	public static void main(String[] args) {
		SpringApplication.run(AmSkF4HUserLgRApplication.class, args);
	}

}
